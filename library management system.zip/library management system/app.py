from flask import Flask, request, render_template, redirect, url_for
import mysql.connector
from datetime import datetime

app = Flask(__name__, template_folder='template_folder')

def get_db_connection():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="library_management"
    )
    return conn

@app.route('/')
def index():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT book_id, title, author, available_copies FROM books')
    books = cursor.fetchall()
    conn.close()
    return render_template('index.html', books=books)

@app.route('/search_book', methods=['POST'])
def search_book():
    title = request.form.get('title', '')
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute('SELECT book_id, title, author, available_copies FROM books WHERE title LIKE %s', ('%' + title + '%',))
    books = cursor.fetchall()
    
    # Fetch and process any remaining results
    if cursor.nextset():
        cursor.fetchall()
    
    conn.close()

    if not books:
        return render_template('search_results.html', message="There is no such book with the given name.", books=[])

    all_out_of_stock = all(book['available_copies'] <= 0 for book in books)
    if all_out_of_stock:
        return render_template('search_results.html', message="All found books are out of stock.", books=[])

    return render_template('search_results.html', books=books)

@app.route('/borrow_book', methods=['POST'])
def borrow_book():
    name = request.form.get('student_name', '')
    email = request.form.get('student_email', '')
    book_id = request.form.get('book_id', '')
    issue_date_str = request.form.get('issue_date', '')
    due_date_str = request.form.get('due_date', '')

    try:
        issue_date = datetime.strptime(issue_date_str, '%Y-%m-%d').date()
        due_date = datetime.strptime(due_date_str, '%Y-%m-%d').date()
    except ValueError:
        return render_template('error.html', message="Invalid date format. Please use YYYY-MM-DD.")

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('SELECT student_id FROM students WHERE email = %s', (email,))
    student = cursor.fetchone()

    if not student:
        cursor.execute('INSERT INTO students (name, email) VALUES (%s, %s)', (name, email))
        conn.commit()
        cursor.execute('SELECT student_id FROM students WHERE email = %s', (email,))
        student = cursor.fetchone()

    student_id = student[0]
    
    cursor.execute('SELECT available_copies FROM books WHERE book_id = %s', (book_id,))
    available_copies = cursor.fetchone()

    if available_copies:
        available_copies = available_copies[0]
        
        if available_copies > 0:
            cursor.execute('INSERT INTO borrow_records (student_id, book_id, issue_date, due_date) VALUES (%s, %s, %s, %s)',
                           (student_id, book_id, issue_date, due_date))
            cursor.execute('UPDATE books SET available_copies = available_copies - 1 WHERE book_id = %s', (book_id,))
            conn.commit()
            conn.close()
            return render_template('success.html', message=f"Book borrowed successfully! Due date is {due_date}.")
        else:
            conn.close()
            return render_template('error.html', message="Sorry, no available copies of this book.")
    else:
        conn.close()
        return render_template('error.html', message="Invalid book ID.")

@app.route('/return_book', methods=['POST'])
def return_book():
    email = request.form.get('return_student_email', '')
    book_id = request.form.get('return_book_id', '')
    return_date_str = request.form.get('return_date', '')

    try:
        return_date = datetime.strptime(return_date_str, '%Y-%m-%d').date()
    except ValueError:
        return render_template('error.html', message="Invalid date format. Please use YYYY-MM-DD.")

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Fetch student ID
        cursor.execute('SELECT student_id FROM students WHERE email = %s', (email,))
        student = cursor.fetchone()
        
        if not student:
            return render_template('error.html', message="Student not found.")

        student_id = student[0]
        
        # Fetch borrow record
        cursor.execute('SELECT borrow_id, issue_date, due_date FROM borrow_records WHERE student_id = %s AND book_id = %s AND return_date IS NULL', (student_id, book_id))
        borrow_record = cursor.fetchone()
        
        if borrow_record:
            borrow_id, issue_date, due_date = borrow_record

            # Calculate fine if applicable
            fine_amount = max((return_date - due_date).days * 20, 0)

            # Update borrow record
            cursor.execute('UPDATE borrow_records SET return_date = %s, fine_amount = %s WHERE borrow_id = %s',
                           (return_date, fine_amount, borrow_id))
            
            # Insert return record
            cursor.execute('INSERT INTO return_records (borrow_id, return_date, fine_amount) VALUES (%s, %s, %s)',
                           (borrow_id, return_date, fine_amount))
            
            # Update available copies of the book
            cursor.execute('UPDATE books SET available_copies = available_copies + 1 WHERE book_id = %s', (book_id,))

            conn.commit()

            return render_template('success.html', message=f"Book returned successfully! Fine amount: {fine_amount}." if fine_amount > 0 else "Book returned successfully without any fine.")
        else:
            return render_template('error.html', message="No record of this book being borrowed by the user.")
    except mysql.connector.Error as err:
        return render_template('error.html', message=f"Database error: {err}")
    finally:
        if cursor.nextset():
            cursor.fetchall()  # Ensure all pending results are processed
        cursor.close()
        conn.close()

@app.route('/user_history', methods=['POST'])
def user_history():
    name = request.form.get('history_name', '').strip()
    email = request.form.get('history_email', '').strip()

    if not name or not email:
        return render_template('error.html', message="Name and Email are required.")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute('SELECT student_id FROM students WHERE name = %s AND email = %s', (name, email))
    student = cursor.fetchone()

    if student:
        student_id = student['student_id']
        cursor.execute('''SELECT b.title, b.author, br.issue_date, br.due_date, br.return_date, br.fine_amount 
                          FROM borrow_records br 
                          JOIN books b ON br.book_id = b.book_id 
                          WHERE br.student_id = %s''', (student_id,))
        borrowed_books = cursor.fetchall()
        
        # Fetch and process any remaining results
        if cursor.nextset():
            cursor.fetchall()
        
        conn.close()
        return render_template('user_history.html', borrowed_books=borrowed_books)
    else:
        conn.close()
        return render_template('error.html', message="User not found.")

if __name__ == "__main__":
    app.run(debug=True)
