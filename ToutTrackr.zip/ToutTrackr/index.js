import express from 'express';
import bodyParser from 'body-parser';
import pg from "pg";
const app = express();
const port = 3000;

app.set('view engine', 'ejs');
const db = new pg.Client({
    user: "postgres",
    host: "localhost",
    database: "hello",
    password: "reshma",
    port: 5432,
  });
  db.connect();
  app.get("/", (req, res) => {
    res.render("home.ejs");
  });

  app.use(express.static('public'));
  app.use(bodyParser.urlencoded({ extended: true }));

  app.get("/login", (req, res) => {
    res.render("login.ejs",{mes:""});
  });
  
  app.get("/register", (req, res) => {
    res.render("register.ejs",{ message:"" });
  });

  
  app.post("/register", async (req, res) => {
    const email = req.body.username;
    const password = req.body.password;
  
    try {
        // Check if the email already exists
        const checkResult = await db.query("SELECT * FROM users WHERE email = $1", [email]);
        if (checkResult.rows.length > 0) {
            res.render("register.ejs", { message: "Email Already Exists... Try Logging In..." });
        } else {
            // If email doesn't exist, insert the new user into the database
            await db.query("INSERT INTO users (email, password) VALUES ($1, $2)", [email, password]);
            res.render("register.ejs", { message: "Successfully Registered... Try Logging In..." });
        }
    } catch (err) {
        console.error("Error during registration:", err);
        res.status(500).send("Internal Server Error");
    }
});



  
app.post("/login", async (req, res) => {
  const email = req.body.username;
  const password = req.body.password;

  try {
      const result = await db.query("SELECT * FROM users WHERE email = $1", [email]);
      if (result.rows.length > 0) {
          const user = result.rows[0];
          const storedPassword = user.password;

          if (password === storedPassword) {
              res.render("index.ejs");
          } else {
              res.render("login.ejs", { mes: "Incorrect Password!...Please Try Again..." });
          }
      } else {
          res.render("login.ejs", { mes: "User Not Found..." });
      }
  } catch (err) {
      console.log(err);
  }
});
const placesData = [
    {
      "place": "SHIMLA (Himachal Pradesh)",
      "price": [
        "1. Rs. 12,500 for 5 days & 4 nights",
        "2. Rs. 10,500 for 4 days & 3 nights",
        "3. Rs. 9,000 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Vrindha Homestay",
        "2. Sterling Legacy",
        "3. Hotel Willow Banks"
      ],
      "attractions": [
        "1. Lower Bazaar",
        "2. Ridge",
        "3. Vaishno Devi Gufa",
        "4. Himalayan Bird Park",
        "5. Kali Bari Temple",
        "6. Kurfi",
        "7. Fagu Wildflower Hall",
        "8. Mahasu Peak"
      ],
      "description": "Shimla, the capital city of Himachal Pradesh, is a charming hill station nestled in the lap of the Himalayas. Renowned for its scenic beauty, colonial architecture, and cultural heritage, Shimla offers a delightful escape into the tranquility of the mountains. Explore the winding streets of Mall Road, adorned with colonial-era buildings and bustling markets. Immerse yourself in the breathtaking vistas of the surrounding valleys and snow-capped peaks from popular vantage points like the Ridge and Jakhoo Hill. Indulge in adventure activities like trekking, paragliding, and skiing in the nearby mountains. Discover the rich history and heritage of Shimla through its historic landmarks such as Viceregal Lodge, Christ Church, and Gaiety Theatre. With its pleasant climate, stunning landscapes, and vibrant atmosphere, Shimla beckons travelers to experience the magic of the Himalayas."
    },
    {
      "place": "MANALI (Himachal Pradesh)",
      "price": [
        "1. Rs. 14,999 for 5 days & 4 nights",
        "2. Rs. 8,200 for 4 days & 3 nights",
        "3. Rs. 7,500 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. The Orchard Greens Resort",
        "2. The Pine Chalet Mountain View Rooms",
        "3. Iris Cottage"
      ],
      "attractions": [
        "1. Hidimba Devi Temple",
        "2. Tibetan Monastery",
        "3. Solang Valley",
        "4. Rohtang Pass",
        "5. Kullu Valley",
        "5. Naggar Castle"
      ],
  "description": "Manali, nestled in the picturesque Kullu Valley of Himachal Pradesh, is a haven for nature lovers and adventure enthusiasts alike. Surrounded by snow-capped mountains, lush valleys, and gushing rivers, Manali offers a perfect blend of natural beauty and thrilling experiences. Explore the charming streets of Old Manali, dotted with traditional wooden houses, vibrant cafes, and local markets selling handicrafts and souvenirs. Embark on scenic drives to nearby attractions like Rohtang Pass, Solang Valley, and Hadimba Temple, offering panoramic views of the Himalayan landscape. Indulge in adventure sports such as paragliding, river rafting, and skiing during the winter months. Experience the local culture and traditions by attending cultural performances, visiting ancient temples, and sampling delicious Himachali cuisine. Whether you seek adventure, relaxation, or cultural immersion, Manali promises an unforgettable retreat in the lap of nature."
  
    },
    {
      "place": "SRINAGAR (Jammu and Kashmir)",
      "price": [
        "1. Rs. 14,800 for 5 days & 4 nights",
        "2. Rs. 12,999 for 4 days & 3 nights",
        "3. Rs. 10,500 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Hotel Ahdoos",
        "2. Solar Residency",
        "3. The Grand Manta",
        "4. Winterfell Inn"
      ],
      "attractions": [
        "1. Shalimar Bagh",
        "2. Nishat Bagh",
        "3. Cheshma Shahi",
        "4. Shankarachariya Temple",
        "5. Shikara Ride on Dal Lake",
        "6. Gulmarg",
        "7. Pristine Lakes",
        "8. Mighty Glaciers"
      ],
  "description": "Srinagar, the summer capital of Jammu and Kashmir, is a paradise nestled in the heart of the Himalayas. Renowned for its breathtaking landscapes, serene lakes, and Mughal gardens, Srinagar exudes timeless beauty and tranquility. Explore the iconic Dal Lake, where shimmering waters reflect the majestic peaks of the surrounding mountains, and vibrant houseboats offer a unique accommodation experience. Wander through the historic lanes of the Old City, adorned with intricately carved wooden mosques, bustling bazaars, and traditional Kashmiri handicraft shops. Visit the enchanting Mughal gardens of Nishat Bagh, Shalimar Bagh, and Chashme Shahi, showcasing exquisite terraced lawns, colorful flowerbeds, and cascading fountains. Experience the rich cultural heritage of Kashmir by sampling the region's culinary delights, such as Wazwan cuisine and traditional Kashmiri tea, known as Kahwa. Immerse yourself in the soul-stirring melodies of Sufi music and the vibrant celebrations of local festivals like Shikara Festival and Tulip Festival. With its unparalleled beauty and warm hospitality, Srinagar invites visitors to embark on a journey of discovery and serenity amidst the majestic Himalayan landscape."
  
    },
    {
      "place": "GANGTOK (Sikkim)",
      "price": [
        "1. Rs. 18,500 for 5 days & 4 nights",
        "2. Rs. 15,200 for 4 days & 3 nights",
        "3. Rs. 13,000 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Mayfair Spa Resort",
        "2. Lemon Tree Hotel",
        "3. The Golden Crest"
      ],
      "attractions": [
        "1. Glacial Tsomgo Lake",
        "2. Baba Mandir",
        "3. Nathula",
        "4. Tashi Viewpoint",
        "5. Ganesh Tok",
        "6. Cottage Industry"
      ],
  "description": "Gangtok, the capital city of Sikkim, is a charming hill station nestled in the Eastern Himalayas. Surrounded by snow-capped peaks, lush valleys, and cascading waterfalls, Gangtok offers a mesmerizing blend of natural beauty, rich culture, and adventure. Explore the vibrant streets lined with colorful Tibetan prayer flags, bustling markets, and traditional Sikkimese architecture. Visit the iconic Rumtek Monastery, a sacred Buddhist site adorned with intricate murals, statues, and religious relics. Experience panoramic views of the Himalayan range from the scenic Tashi Viewpoint and Ganesh Tok. Indulge in adventurous activities like trekking, paragliding, and river rafting amidst the breathtaking landscapes of Gangtok. Immerse yourself in the local culture by attending traditional dance performances, sampling authentic Sikkimese cuisine, and exploring the local markets for handicrafts and souvenirs. Discover the tranquil beauty of Gangtok's surrounding countryside with visits to serene lakes like Tsomgo Lake and picturesque valleys like Yumthang Valley. With its serene ambiance, majestic scenery, and warm hospitality, Gangtok promises an unforgettable experience for nature lovers, adventure enthusiasts, and culture seekers alike."
    },
    {
      "place": "AGRA (Uttar Pradesh,Delhi)",
      "price": [
        "1. Rs. 11,500 for 5 days & 4 nights",
        "2. Rs. 9,000 for 4 days & 3 nights",
        "3. Rs. 7,250 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Radisson Hotel",
        "2. Taj Hotel & Convention Centre",
        "3. Howard Plaza The Fern - An Ecotel Hotel"
      ],
      "attractions": [
        "1. Sunrise at Taj Mahal",
        "2. Akshardham Temple",
        "3. Water Show - Agra India Gate",
        "4. Rashtrapathi Bhawan",
        "5. Lotus Temple",
        "6. Garden of Five Senses"
      ],
  "description": "Agra, a city steeped in history and romance, is home to one of the most iconic monuments in the world, the majestic Taj Mahal. Situated on the banks of the Yamuna River in Uttar Pradesh, Agra beckons travelers with its architectural marvels, rich heritage, and cultural significance. Marvel at the breathtaking beauty of the Taj Mahal, a UNESCO World Heritage Site and a symbol of eternal love, as its ivory-white marble shimmers in the sunlight. Explore the grandeur of the Agra Fort, a UNESCO-listed fortress-palace showcasing Mughal architecture at its finest, with its intricate carvings, imposing gateways, and panoramic views of the city. Discover the splendid architecture of Fatehpur Sikri, an abandoned Mughal city filled with historic palaces, mosques, and courtyards, reflecting the grandeur of Emperor Akbar's reign. Delve into Agra's vibrant culture and heritage by exploring its bustling bazaars, sampling delectable street food, and witnessing traditional art forms like marble inlay work and miniature painting. Experience the magic of Agra's historic monuments at sunrise and sunset, when the soft hues of the sky cast a golden glow upon the city, creating an atmosphere of timeless beauty and romance."
    },
    {
      "place": "MUNNAR (Alleppey,Kerala)",
      "price": [
        "1. Rs. 17,920 for 5 days & 4 nights",
        "2. Rs. 14,570 for 4 days & 3 nights",
        "3. Rs. 9,500 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Palmy Lake Resort",
        "2. Classic Regency",
        "3. Misty Mountain Resort",
        "4. Munnar Ice Queen Rooms and Cottages"
      ],
      "attractions": [
        "1. Spice Plantations",
        "2. Valara and Cheeyappara Waterfalls",
        "3. Anamudi Peak",
        "4. Tea Museum",
        "5. Jungle Safari at Thekkady",
        "6. Bamboo Rafting and Trekking"
      ],
  "description": "Nestled amidst the picturesque landscapes of Kerala, Munnar is a serene hill station renowned for its lush tea plantations, mist-covered hills, and tranquil ambiance. Situated in the Western Ghats at an altitude of 1,600 meters above sea level, Munnar offers a perfect retreat for nature lovers, adventure enthusiasts, and honeymooners alike. Explore the verdant tea estates of Munnar, where emerald-green tea bushes carpet the hillsides, creating a mesmerizing sight against the backdrop of misty mountains. Embark on scenic drives through winding roads flanked by dense forests, waterfalls, and spice plantations, offering panoramic views of the surrounding valleys and valleys. Immerse yourself in the tranquility of Munnar's pristine lakes and waterfalls, such as the enchanting Attukal Waterfalls and the serene Kundala Lake, where you can enjoy boating amidst the mist-covered hills. Discover the rich biodiversity of Eravikulam National Park, home to the endangered Nilgiri Tahr and a variety of flora and fauna, including rare orchids and butterflies. Indulge in adventurous activities like trekking, rock climbing, and mountain biking amidst the scenic trails of Munnar, offering breathtaking views of the rolling hills and tea gardens. Experience the warm hospitality of Munnar's resorts and homestays, where you can unwind in cozy accommodations surrounded by nature's tranquility and indulge in authentic Kerala cuisine prepared with fresh local ingredients. Whether you seek adventure, relaxation, or simply a chance to connect with nature, Munnar promises an unforgettable escape amidst the breathtaking beauty of Kerala's hill country."
    },
    {
      "place": "DARJEELING (West Bengal)",
      "price": [
        "1. Rs. 19,200 for 5 days & 4 nights",
        "2. Rs. 17,500 for 4 days & 3 nights",
        "3. Rs. 15,750 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Hotel Sonar Bangla",
        "2. Mount Conifer Suites",
        "3. Muscatel Himalayan Resort"
      ],
      "attractions": [
        "1. Tiger Hill",
        "2. Dro-Dul-Chorten",
        "3. Ghoom Monastery",
        "4. Batasia Loop",
        "5. Himalayan Mountaineering Institute",
        "6. Tenzing Rock"
      ],
  "description": "Perched in the foothills of the majestic Himalayas, Darjeeling is a charming hill station renowned for its breathtaking vistas, tea gardens, and vibrant culture. Situated in the state of West Bengal, India, Darjeeling offers a perfect blend of natural beauty, colonial charm, and cultural heritage. Explore the lush tea estates of Darjeeling, where emerald-green tea bushes carpet the rolling hillsides, creating a mesmerizing landscape against the backdrop of snow-capped peaks. Savour the aroma and taste of Darjeeling's world-famous tea, known for its unique flavor and aroma, by visiting the iconic tea gardens and tea factories dotting the region. Witness the awe-inspiring sunrise over the snow-clad peaks of Kanchenjunga from the vantage point of Tiger Hill, a mesmerizing sight that attracts visitors from around the world. Immerse yourself in Darjeeling's rich cultural tapestry by exploring its bustling markets, vibrant monasteries, and colonial-era architecture, including the iconic Darjeeling Himalayan Railway, a UNESCO World Heritage Site. Discover the spiritual side of Darjeeling at the ancient monasteries of Ghoom and Bhutia Busty, where you can witness traditional rituals and ceremonies amidst serene surroundings. Indulge in adventurous activities like trekking, mountain biking, and paragliding amidst the scenic trails and valleys of Darjeeling, offering breathtaking views of the Himalayan landscape. Experience the warm hospitality of Darjeeling's cozy guesthouses and heritage hotels, where you can unwind in comfortable accommodations with panoramic views of the mountains and valleys. Whether you seek adventure, relaxation, or cultural immersion, Darjeeling promises an unforgettable retreat amidst the splendor of the Himalayas."
    },
    {
      "place": "GOA",
      "price": [
        "1. Rs. 14,000 for 5 days & 4 nights",
        "2. Rs. 11,500 for 4 days & 3 nights",
        "3. Rs. 9,000 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Hard Rock Hotel Goa Calangute",
        "2. Stone Water Eco Resort",
        "3. Park Inn by Radisson Goa Candolim"
      ],
      "attractions": [
        "1. Shri Shantadurga Temple at Kavlem",
        "2. Shri Manguesh Temple at Priol",
        "3. Portuguese architectural buildings"
      ],
  "description": "Nestled along the sun-drenched shores of the Arabian Sea, Goa is a tropical paradise renowned for its pristine beaches, vibrant culture, and rich heritage. With its captivating blend of Portuguese influence and Indian charm, Goa offers a unique and unforgettable experience for travelers. Explore Goa's picturesque coastline, which stretches for miles and boasts some of the most beautiful beaches in the world. From the bustling shores of Calangute and Baga to the tranquil sands of Palolem and Agonda, each beach offers its own distinct vibe and activities, including water sports, beach parties, and sunset cruises. Immerse yourself in Goa's rich cultural tapestry by exploring its historic churches, colorful markets, and lively festivals. Visit the UNESCO-listed churches of Old Goa, such as the Basilica of Bom Jesus and Se Cathedral, which showcase stunning architecture and centuries-old religious traditions. Indulge your taste buds in Goa's diverse cuisine, which blends local flavors with Portuguese influences to create mouthwatering dishes like vindaloo, xacuti, and bebinca. Sample fresh seafood at beachside shacks, sip on feni, Goa's signature spirit, and feast on traditional Goan sweets like bebinca and dodol. Dive into Goa's vibrant nightlife, which comes alive with beach parties, live music, and vibrant street markets. Dance the night away at popular clubs and bars in North Goa, or unwind with a beachside bonfire under the stars. For a more relaxed experience, explore the quaint villages and scenic backwaters of South Goa, where you can unwind in luxury resorts and boutique guesthouses amidst lush greenery and serene surroundings. Whether you're seeking adventure, relaxation, or cultural immersion, Goa offers something for every traveler, making it the ultimate destination for a tropical getaway."
    },
    {
      "place": "UDAIPUR (Rajasthan)",
      "price": [
        "1. Rs. 12,999 for 5 days & 4 nights",
        "2. Rs. 9,500 for 4 days & 3 nights",
        "3. Rs. 6,499 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Manuscript Jhilwara Haveli",
        "2. Hotel Bawa Udaipur",
        "3. Hotel Lakend"
      ],
      "attractions": [
        "1. City Palace",
        "2. Jagdish Temple",
        "3. Fateh Sagar",
        "4. Shilpgram",
        "5. Kumbhalgarh Fort",
        "6. Chittorgarh Fort"
      ],
  "description": "Known as the 'City of Lakes' and the 'Venice of the East', Udaipur is a majestic oasis nestled in the heart of Rajasthan, India. Steeped in history, culture, and architectural splendor, Udaipur captivates visitors with its regal charm and timeless beauty. Explore the enchanting City Palace, a magnificent complex of palaces, courtyards, and gardens overlooking the tranquil waters of Lake Pichola. Admire the intricate craftsmanship and ornate design of the palace, which reflects a fusion of Rajput and Mughal architectural styles. Cruise along Lake Pichola aboard a traditional boat, marveling at the picturesque views of the city's iconic landmarks, including the Lake Palace and Jag Mandir Island. Discover the rich cultural heritage of Udaipur at the Bagore Ki Haveli Museum, which showcases a stunning collection of artifacts, costumes, and musical instruments. Witness the vibrant colors and traditional performances of Rajasthan's folk dances, music, and puppet shows, transporting you back in time to the era of royalty. Indulge your senses in Udaipur's culinary delights, from traditional Rajasthani thalis to Mewari delicacies, served in royal settings with impeccable hospitality. Savor the flavors of local specialties like dal baati churma, gatte ki sabzi, and laal maas, accompanied by freshly baked bread and aromatic spices. Immerse yourself in the tranquility of Udaipur's serene lakes and lush gardens, where you can unwind amidst the natural beauty and scenic landscapes. Take a leisurely stroll through the Saheliyon Ki Bari, a royal garden adorned with fountains, marble pavilions, and colorful flowers, offering a peaceful retreat from the hustle and bustle of the city. For a truly unforgettable experience, stay in one of Udaipur's luxurious heritage hotels or boutique palaces, where you can indulge in royal hospitality and experience the grandeur of Rajasthan's royal past. Whether you're exploring historic palaces, cruising on pristine lakes, or savoring local delicacies, Udaipur promises an enchanting journey through the rich tapestry of Rajasthan's culture and heritage."
    },
    {
      "place": "JAIPUR (Rajasthan)",
      "price": [
        "1. Rs. 12,500 for 5 days & 4 nights",
        "2. Rs. 10,200 for 4 days & 3 nights",
        "3. Rs. 7,500 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Four Points by Sheraton Jaipur",
        "2. Golden Tulip Essential",
        "3. The Lalit"
      ],
      "attractions": [
        "1. Fatehpur Sikri",
        "2. Red Sandstone City",
        "3. Jama Masjid",
        "4. Diwan-e-aam",
        "5. Buland Darwaza",
        "6. Amber Fort"
      ],
  "description": "Welcome to Jaipur, the 'Pink City' and the crown jewel of Rajasthan's rich cultural heritage. Steeped in history and architectural grandeur, Jaipur beckons travelers with its vibrant bazaars, majestic forts, and opulent palaces. Explore the iconic Hawa Mahal, a mesmerizing palace adorned with intricate lattice work and honeycomb windows, offering a glimpse into Jaipur's royal past. Marvel at the majestic Amber Fort, a UNESCO World Heritage Site, perched atop a hilltop overlooking the scenic Maota Lake. Immerse yourself in the rich tapestry of Rajasthani culture at the City Palace, a sprawling complex of palaces, courtyards, and museums showcasing royal artifacts and regal treasures. Discover the architectural marvel of Jantar Mantar, an astronomical observatory built by Maharaja Jai Singh II, featuring a collection of ancient astronomical instruments. Dive into the vibrant bazaars of Jaipur, where you can shop for exquisite handicrafts, textiles, and jewelry, including the renowned Jaipuri quilts, gemstones, and traditional Rajasthani attire. Indulge your taste buds in Jaipur's culinary delights, from mouthwatering Rajasthani thalis to flavorful street food like pyaaz kachori and ghewar, served with a generous dose of hospitality. Experience the colorful festivities of Jaipur's festivals, including the vibrant celebrations of Diwali, Holi, and the spectacular Jaipur Literature Festival, attracting literary enthusiasts from around the world. For a truly regal experience, stay in one of Jaipur's heritage hotels or boutique palaces, where you can immerse yourself in the grandeur of Rajasthan's royal heritage. Whether you're exploring historic forts, shopping in bustling bazaars, or savoring local cuisine, Jaipur offers an unforgettable journey through the enchanting landscapes of Rajasthan."
    },
    {
      "place": "AMRITSAR (Punjab)",
      "price": [
        "Rs. 17,100 for 5 days & 4 nights",
        "Rs. 14,500 for 4 days & 3 nights",
        "Rs. 12,000 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. One Earth GG Regency",
        "2. Country Inn Hall of Heritage",
        "3. Hotel Levelup Signature"
      ],
      "attractions": [
        "1. Golden Temple",
        "2. Jallianwala Bagh",
        "3. Ram Bagh",
        "4. Maharaja Ranjit Singh Summer Palace Museum",
        "5. Akal Takht"
      ],
  "description": "Welcome to Amritsar, the spiritual and cultural heart of Punjab, where history, tradition, and spirituality converge to create a unique tapestry of experiences. Home to the iconic Golden Temple, the holiest shrine of Sikhism, Amritsar draws pilgrims and travelers alike with its serene ambiance and sacred aura. Witness the mesmerizing sight of the Golden Temple, shimmering in the waters of the Amrit Sarovar, especially enchanting during the magical hour of sunset. Explore the historic Jallianwala Bagh, a poignant memorial commemorating the tragic massacre of innocent civilians by British troops in 1919, a reminder of India's struggle for independence. Immerse yourself in the vibrant culture of Punjab at the bustling streets of Amritsar, where you can savor authentic Punjabi cuisine, shop for colorful traditional attire and handicrafts, and witness exhilarating performances of bhangra and gidda. Delight your taste buds with Amritsari delicacies like the famous Amritsari kulcha, chole bhature, and the delectable langar served at the Golden Temple, a symbol of Sikh values of equality and community service. Experience the spiritual fervor of the Wagah Border ceremony, a daily military parade and flag-lowering ceremony performed with great pomp and showmanship, symbolizing the camaraderie and rivalry between India and Pakistan. Discover the rich heritage of Sikhism at the enlightening Sikh Museum, showcasing artifacts, paintings, and manuscripts depicting the history and philosophy of Sikh gurus. For a peaceful retreat amidst lush greenery, visit the serene Ram Bagh Gardens, a historic garden built by Maharaja Ranjit Singh, offering a tranquil escape from the hustle and bustle of city life. With its blend of spirituality, history, and hospitality, Amritsar invites you to embark on a soul-stirring journey through the heart of Punjab."
    },
    {
      "place": "COORG (Mysore,Karnataka)",
      "price": [
        "1. Rs. 16,029 for 5 days & 4 nights",
        "2. Rs. 13,700 for 4 days & 3 nights",
        "3. Rs. 10,999 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Purple Palms Resort",
        "2. Heights Farm Stay",
        "3. Montrose Golf Resort"
      ],
      "attractions": [
        "1. Dubare Reserve Forest",
        "2. Thalakaveri",
        "3. Bhagamandala",
        "4. Talacauvery",
        "5. Abbi Falls"
      ],
  "description": "Nestled amidst the verdant hills of Karnataka, Coorg, also known as Kodagu, is a picturesque destination renowned for its lush coffee plantations, mist-covered hills, and tranquil landscapes. Explore the captivating beauty of Coorg as you meander through acres of emerald green coffee estates, breathing in the fragrant aroma of freshly brewed coffee. Immerse yourself in the serenity of nature as you embark on leisurely walks or adventurous treks through dense forests, encountering cascading waterfalls, gurgling streams, and exotic flora and fauna along the way. Indulge in the rich cultural heritage of Coorg as you interact with the warm and hospitable locals, known for their vibrant traditions and hospitality. Discover the enchanting Abbey Falls, where the river Cauvery cascades down rocky cliffs amidst lush foliage, creating a breathtaking spectacle. Experience the thrill of white-water rafting on the gushing waters of the Barapole River, surrounded by the pristine beauty of the Western Ghats. Visit the historic Madikeri Fort, an ancient hill fort built by the erstwhile rulers of Coorg, offering panoramic views of the surrounding hills and valleys. Delight your taste buds with authentic Coorgi cuisine, known for its delectable flavors and aromatic spices, including specialties like pandi curry (pork curry), kadambuttu (steamed rice dumplings), and akki rotti (rice pancakes). Experience the unique charm of Coorg's homestays, where you can immerse yourself in the local culture and hospitality while enjoying the comforts of home-cooked meals and personalized experiences. Whether you're seeking adventure, relaxation, or cultural immersion, Coorg offers a perfect blend of natural beauty, heritage, and tranquility, inviting you to unwind and rejuvenate amidst the breathtaking landscapes of the 'Scotland of India."
    },
    {
      "place": "OOTY (Coonoor, Kodaikanal, Tamil Nadu)",
      "price": [
        "1. Rs. 18,200 for 5 days & 4 nights",
        "2. Rs. 15,500 for 4 days & 3 nights",
        "3. Rs. 12,809 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Berry Dale Comfort Stay",
        "2. Devashola",
        "3. Hotel Grand Palace"
      ],
      "attractions": [
        "1. Ooty lake",
        "2. Black Thunder",
        "3. Wax World",
        "4. Deer Park",
        "5. Mudumalai National Park"
      ],
  "description": "Nestled in the lap of the Nilgiri Hills, Ooty, also known as Udhagamandalam, is a charming hill station in Tamil Nadu, India. Renowned for its serene landscapes, cool climate, and lush greenery, Ooty offers a tranquil retreat for nature lovers and adventure enthusiasts alike. Explore the scenic beauty of Ooty as you wander through verdant tea gardens, fragrant eucalyptus forests, and sprawling botanical gardens. Admire the captivating vistas of the Nilgiri Hills from the vantage points of Doddabetta Peak and Needle Rock Viewpoint, where the mist-covered mountains stretch as far as the eye can see. Embark on a leisurely boat ride across the tranquil waters of Ooty Lake, surrounded by picturesque hills and verdant landscapes. Discover the rich biodiversity of the region at the Government Botanical Garden, home to thousands of exotic plant species, including rare orchids and ferns. Unleash your adventurous spirit with activities like trekking, mountain biking, and horse riding amidst the scenic trails of the Nilgiris, offering breathtaking views of cascading waterfalls and lush valleys. Experience the old-world charm of the UNESCO World Heritage Nilgiri Mountain Railway, as you journey through winding tracks and verdant landscapes aboard the quaint steam locomotive, fondly known as the 'Toy Train.' Indulge your taste buds with delectable South Indian cuisine, including piping hot idlis, crispy dosas, and aromatic filter coffee, served in local eateries and roadside stalls. Immerse yourself in the vibrant culture of Ooty as you explore traditional markets, bustling with activity and colorful handicrafts, spices, and souvenirs. Whether you seek adventure, relaxation, or cultural immersion, Ooty promises an unforgettable experience amidst the breathtaking beauty of the Nilgiri Hills."
    },
    {
      "place": "LONAVALA (Lavasa, Shaniwar Wada, Pune, Maharashtra)",
      "price": [
        "1. Rs. 14,500 for 5 days & 4 nights",
        "2. Rs. 12,000 for 4 days & 3 nights",
        "3. Rs. 10,700 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Ekaant The Retreat",
        "2. Siddhi Holiday Lonavala",
        "3. The Mango Leaf Lake Resort"
      ],
      "attractions": [
        "1. Bhushi Dam",
        "2. Tiger Point",
        "3. Was Museum",
        "4. Khandala Rajmachi Point"
      ],
  "description": "Nestled amidst the lush Sahyadri Mountains in Maharashtra, Lonavala is a picturesque hill station known for its scenic beauty, historic forts, and serene lakes. Explore the mesmerizing landscapes of Lonavala as you journey through verdant valleys, cascading waterfalls, and dense forests teeming with wildlife. Admire the panoramic views of the surrounding hills from the vantage points of Tiger Point and Lion's Point, where the mist-clad mountains create a mystical ambiance. Discover the rich heritage of the region with visits to historic landmarks like the iconic Shaniwar Wada fort in nearby Pune, steeped in Maratha history and architectural grandeur. Embark on a spiritual journey to the ancient Karla and Bhaja Caves, renowned for their intricate rock-cut architecture and Buddhist carvings dating back to the 2nd century BCE. Indulge your adventurous spirit with thrilling activities like trekking, rappelling, and camping amidst the rugged terrain of the Western Ghats, offering breathtaking views of the surrounding landscapes. Unwind and rejuvenate your senses at scenic lakes like Pawna Lake and Tungarli Lake, where you can enjoy boating, fishing, and lakeside picnics amidst serene surroundings. Delight your taste buds with local delicacies like piping hot vada pav, crispy bhajias, and sweet chikki, available at roadside stalls and local eateries. Immerse yourself in the vibrant culture of Lonavala as you explore bustling markets, vibrant festivals, and traditional dance performances, showcasing the rich heritage of Maharashtra. Whether you seek adventure, relaxation, or cultural immersion, Lonavala offers a perfect getaway amidst the natural splendor of the Western Ghats."
    },
    {
      "place": "COCHIN (Varkala, Kerala)",
      "price": [
        "1. Rs. 16,999 for 5 days & 4 nights",
        "2. Rs. 14,570 for 4 days & 3 nights",
        "3. Rs. 11,999 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Trident Cochin",
        "2. Gokulam Park Hotel",
        "3. Holiday Inn Cochin"
      ],
      "attractions": [
        "1. Colonial Bungalows",
        "2. St. Francis Church",
        "3. 16th-century royal murals",
        "4. Mattancherry Palace"
      ],
  "description": "Cochin, also known as Kochi, is a vibrant port city situated on the southwest coast of India in the picturesque state of Kerala. Renowned for its rich history, diverse culture, and stunning natural beauty, Cochin offers travelers a captivating blend of old-world charm and modern amenities. Explore the historic neighborhoods of Fort Kochi and Mattancherry, where colonial-era buildings, ancient churches, and spice warehouses stand as a testament to the city's storied past. Visit iconic landmarks like the centuries-old Santa Cruz Basilica, Dutch Palace, and the famous Chinese fishing nets lining the shores of the Arabian Sea. Immerse yourself in Cochin's bustling markets, such as the vibrant Jew Town, where you can shop for exquisite handicrafts, spices, and antiques. Experience the cultural melting pot of Cochin by attending traditional Kathakali dance performances, temple festivals, and vibrant street parades that showcase the rich heritage of Kerala. Indulge your palate with a tantalizing array of culinary delights, from fresh seafood delicacies like fish curry and prawn masala to traditional Kerala thalis served on banana leaves. Embark on a scenic backwater cruise along the tranquil waterways of the Kerala backwaters, where you can admire lush greenery, coconut groves, and quaint villages dotting the landscape. Relax and rejuvenate your senses at luxurious Ayurvedic spas and wellness retreats, offering traditional therapies, yoga sessions, and meditation classes amidst serene surroundings. Whether you're exploring historic sites, indulging in culinary adventures, or simply relaxing by the sea, Cochin promises an unforgettable journey filled with warmth, hospitality, and timeless beauty."
    },
    {
      "place": "DHARMASHALA (Himachal Pradesh)",
      "price": [
        "1. Rs. 16,500 for 5 days & 4 nights",
        "2. Rs. 15,000 for 4 days & 3 nights",
        "3. Rs. 13,200 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Meghavan Resort",
        "2. Spring Valley Resort",
        "3. Agastya Residency"
      ],
      "attractions": [
        "1. Bhagsu Nag temple",
        "2. St. John's Church",
        "3. Dalai Lama Temple complex"
      ],
  "description": "Dharamshala, nestled in the picturesque Kangra Valley of Himachal Pradesh, is a serene hill station renowned for its spiritual significance, breathtaking landscapes, and vibrant Tibetan culture. Surrounded by snow-capped mountains, lush greenery, and pristine rivers, Dharamshala offers travelers a tranquil retreat amidst nature's bounty. Explore the vibrant streets of McLeod Ganj, the bustling suburb known as 'Little Lhasa,' where colorful prayer flags flutter in the breeze and the aroma of Tibetan cuisine fills the air. Visit the majestic Tsuglagkhang Complex, home to the residence of His Holiness the Dalai Lama, and seek spiritual solace at the serene Namgyal Monastery, where monks chant prayers and perform rituals. Discover the rich heritage of Tibetan Buddhism at the Tibet Museum, showcasing artifacts, thangka paintings, and historical exhibits that narrate the plight of Tibetan refugees and their cultural legacy. Embark on scenic treks to nearby attractions like Triund, a pristine alpine meadow offering panoramic views of the Dhauladhar Range, or Bhagsu Waterfall, a cascading natural wonder amidst verdant forests and rocky cliffs. Experience the tranquility of Dharamshala's tea gardens, where you can savor aromatic blends of Kangra tea amidst verdant plantations and misty mountain vistas. For adventure enthusiasts, indulge in thrilling activities like paragliding, mountain biking, and rock climbing amidst the rugged terrain of the Himalayas. Unwind and rejuvenate your senses with yoga and meditation retreats, Ayurvedic spa treatments, and wellness programs that promote holistic healing and inner peace. Whether you're seeking spiritual enlightenment, outdoor adventures, or simply a peaceful escape from the hustle and bustle of city life, Dharamshala beckons with its serene beauty and warm hospitality."
    },
    {
      "place": "KHAJURAHO (Bhedaghat, Madhya Pradesh)",
      "price": [
        "1. Rs. 24,899 for 5 days & 4 nights",
        "2. Rs. 21,500 for 4 days & 3 nights",
        "3. Rs. 18,000 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. The Bundela",
        "2. AS Hotels Khajuraho",
        "3. Shagun Resort"
      ],
      "attractions": [
        "1. Jungle safari at Tala",
        "2. Magadhi",
        "3. Khitauli Zone",
        "4. Light and Sound Show"
      ],
  "description": "Khajuraho, located in the heart of Madhya Pradesh, is a UNESCO World Heritage Site renowned for its stunning group of medieval Hindu and Jain temples adorned with intricate carvings and sculptures. These temples, built between the 9th and 11th centuries by the Chandela dynasty, are renowned for their exquisite architecture, intricate artwork, and sensuous sculptures that depict various aspects of life, spirituality, and divine beings. Explore the intricately carved temples dedicated to Hindu gods like Vishnu, Shiva, and Devi, as well as Jain deities, showcasing a blend of architectural styles and iconography. Marvel at the intricate details of the sculptures, depicting celestial nymphs, gods, goddesses, mythical creatures, and scenes from Hindu epics like the Mahabharata and Ramayana. The temples are divided into three groups – the Western, Eastern, and Southern clusters – each offering a unique architectural and artistic experience. Discover the rich cultural heritage of Khajuraho at the Archaeological Museum, which houses a collection of sculptures, artifacts, and antiquities excavated from the region, providing insights into the history and significance of the site. Immerse yourself in the vibrant culture of Madhya Pradesh with traditional dance performances, folk music, and cultural festivals that celebrate the rich artistic legacy of the region. Experience the natural beauty of Bhedaghat, a nearby destination known for its stunning marble rock formations, cascading waterfalls, and boat rides along the Narmada River amidst towering cliffs and lush forests. Khajuraho offers visitors a unique opportunity to delve into the rich tapestry of India's cultural and architectural heritage, with its exquisite temples, intricate sculptures, and timeless tales of love, devotion, and spirituality."
    },
    {
      "place": "JODHPUR (Jaisalmer, Rajasthan)",
      "price": [
        "1. Rs. 13,870 for 5 days & 4 nights",
        "2. Rs. 11,200 for 4 days & 3 nights",
        "3. Rs. 9,500 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Hotel Omni Plaza",
        "2. Gorbandh Palace",
        "3. Hotel Swan Haveli"
      ],
      "attractions": [
        "1. Mehrangarh Fort",
        "2. Umaid Bhawan Palace",
        "3. Sonar Quila"
      ],
      "description": "Jodhpur, also known as the 'Blue City' and 'Sun City', is a majestic desert city located in the heart of Rajasthan, India. It is renowned for its stunning architecture, vibrant culture, and rich history that dates back to the reign of the Rathore dynasty. Explore the majestic Mehrangarh Fort, perched atop a rocky hill, offering panoramic views of the city's skyline and surrounding desert landscape. Marvel at the intricate carvings, expansive courtyards, and ornate palaces within the fort complex, which houses a museum showcasing a magnificent collection of royal artifacts, paintings, and weaponry. Wander through the narrow lanes of the historic old town, adorned with indigo-blue houses, bustling bazaars, and ornate havelis, reflecting the city's vibrant cultural heritage. Discover the opulent Umaid Bhawan Palace, one of the world's largest private residences, known for its majestic architecture, lush gardens, and regal interiors. Experience the vibrant colors and flavors of Rajasthan at the bustling markets of Sardar Market and Clock Tower, where you can shop for traditional handicrafts, textiles, spices, and jewelry. Delve into the rich cultural tapestry of Jodhpur through its folk music and dance performances, showcasing the vibrant traditions of the region. Explore the nearby desert oasis of Jaisalmer, known for its magnificent sand dunes, camel safaris, and ancient forts, offering a glimpse into the desert way of life. Whether you're exploring the majestic forts, admiring the intricate architecture, or immersing yourself in the vibrant culture, Jodhpur promises an unforgettable journey through the enchanting landscapes and timeless traditions of Rajasthan."
    },
    {
      "place": "WAYANAD (Kerala)",
      "price": [
        "1. Rs. 12,999 for 5 days & 4 nights",
        "2. Rs. 10,500 for 4 days & 3 nights",
        "3. Rs. 8,000 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. The Serenity Resort",
        "2. Wayanad Fort Resort",
        "3. Cloud Heaven Holiday Homes"
      ],
      "attractions": [
        "1. Pookode Lake",
        "2. En Ooru Tribal Village",
        "3. Lakkidi View Point"
      ],
      "description":"Wayanad, located in the verdant hills of Kerala, is a picturesque destination known for its lush greenery, misty mountains, and rich biodiversity. Nestled amidst the Western Ghats, Wayanad offers a serene escape into nature, with its sprawling tea estates, dense forests, and glistening waterfalls. Explore the tranquil backwaters of the Banasura Sagar Dam, or embark on a thrilling trek to the Chembra Peak for breathtaking views of the surrounding landscape. Discover the region's vibrant tribal culture and heritage by visiting the Edakkal Caves, adorned with ancient rock art dating back thousands of years. With its refreshing climate, diverse wildlife, and enchanting landscapes, Wayanad beckons travelers to immerse themselves in the beauty of God's Own Country."
    },
    {
      "place": "HYDERABAD (Telangana)",
      "price": [
        "1. Rs. 14,080 for 5 days & 4 nights",
        "2. Rs. 11,750 for 4 days & 3 nights",
        "3. Rs. 8,999 for 3 days & 2 nights"
      ],
      "hotels": [
        "1. Aditya Park Hyderabad - A Sarovar Hotel",
        "2. The Golconda Hotel",
        "3. Oakwood Residence"
      ],
      "attractions": [
        "1. Charminar",
        "2. ISKCON Temple",
        "3. Birla Mandir",
        "4. Ramoji Film City"
      ],
  "description": "Hyderabad, the vibrant capital city of Telangana, is a fascinating blend of tradition and modernity, boasting a rich history, diverse culture, and bustling urban life. Explore the iconic landmarks of Hyderabad, such as the majestic Charminar, a magnificent monument built in the 16th century, known for its intricate architecture and bustling markets surrounding it. Discover the opulent heritage of the Nizams at the historic Chowmahalla Palace, a UNESCO World Heritage Site, showcasing exquisite architecture, luxurious interiors, and a vast collection of artifacts. Delve into the grandeur of the Golconda Fort, an ancient fortress perched atop a hill, offering panoramic views of the city and captivating sound and light shows narrating its legendary history. Experience the spiritual ambiance of the Birla Mandir, a marble temple dedicated to Lord Venkateswara, adorned with intricate carvings and surrounded by landscaped gardens. Indulge in the culinary delights of Hyderabad, renowned for its flavorful biryanis, kebabs, and traditional sweets like double ka meetha and qubani ka meetha. Wander through the vibrant lanes of the old city, filled with bustling bazaars, aromatic spice markets, and vibrant street food stalls, offering a sensory feast for visitors. Explore the modern side of Hyderabad at HITEC City, a hub of technology and innovation, home to multinational companies, luxury hotels, and shopping malls. Experience the warmth and hospitality of the locals, known for their unique dialect, Hyderabadi Urdu, and traditional attire like the iconic Hyderabadi sherwani and khada dupatta. Whether you're intrigued by history, culture, or gastronomy, Hyderabad promises an enriching and unforgettable experience for every traveler."
    }
  ];
app.get('/package', (req, res) => {
    res.render('package.ejs', { places: placesData });
  });
  app.post('/details', (req, res) => {
    const selectedPlace = req.body.place;
    const placeDetails = placesData.find(place => place.place === selectedPlace);
    if (placeDetails) {
      res.json(placeDetails);
    } else {
      res.status(404).json({ error: 'Place not found' });
    }
  });
  
  app.post('/checkout', (req, res) => {
    const destinationURL = "https://cosmofeed.com/vp/661bc18afac16e0013eacc19";
    res.redirect(destinationURL);
  });

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});